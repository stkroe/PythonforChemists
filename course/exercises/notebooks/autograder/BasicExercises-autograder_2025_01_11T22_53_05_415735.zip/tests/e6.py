OK_FORMAT = True

test = {   'name': 'e6',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_my_list():\n'
                                               '...     my_list()\n'
                                               '...     captured = capsys.readouterr()\n'
                                               '...     output = captured.out.splitlines()\n'
                                               "...     assert output == ['[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]']\n",
                                       'hidden': True,
                                       'locked': False},
                                   {'code': '>>> test_my_list()\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
