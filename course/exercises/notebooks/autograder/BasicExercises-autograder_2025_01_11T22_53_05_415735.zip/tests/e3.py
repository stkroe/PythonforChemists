OK_FORMAT = True

test = {   'name': 'e3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_print_working_directory(capsys):\n'
                                               '...     print_working_directory()\n'
                                               '...     captured = capsys.readouterr()\n'
                                               '...     output = captured.out.strip()\n'
                                               '...     assert output == os.getcwd()\n',
                                       'hidden': True,
                                       'locked': False},
                                   {'code': '>>> test_print_working_directory(capsys)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
