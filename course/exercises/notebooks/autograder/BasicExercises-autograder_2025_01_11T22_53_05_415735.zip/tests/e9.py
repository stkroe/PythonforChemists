OK_FORMAT = True

test = {   'name': 'e9',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_list_comprehension(capsys):\n'
                                               '...     list_comprehension()\n'
                                               '...     captured = capsys.readouterr()\n'
                                               '...     output = captured.out.splitlines()\n'
                                               "...     assert output == ['[0, 2, 4, 6, 8]']\n",
                                       'hidden': True,
                                       'locked': False},
                                   {'code': '>>> test_list_comprehension()\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
