OK_FORMAT = True

test = {   'name': 'e10',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_check_even():\n'
                                               "...     assert check_even([2, 4, 6]) == 'True'\n"
                                               "...     assert check_even([1, 3, 5]) == 'False'\n"
                                               "...     assert check_even([2, 4, 5]) == 'False'\n",
                                       'hidden': True,
                                       'locked': False},
                                   {'code': '>>> test_check_even()\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
