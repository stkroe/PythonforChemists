OK_FORMAT = True

test = {   'name': 'e4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_list_files(capsys):\n'
                                               '...     list_files()\n'
                                               '...     captured = capsys.readouterr()\n'
                                               '...     output = captured.out.splitlines()\n'
                                               '...     assert set(output) == set(os.listdir())\n',
                                       'hidden': True,
                                       'locked': False},
                                   {'code': '>>> test_list_files(capsys)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
