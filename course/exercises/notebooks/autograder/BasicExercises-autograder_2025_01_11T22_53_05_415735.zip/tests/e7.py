OK_FORMAT = True

test = {   'name': 'e7',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_list_operations(capsys):\n'
                                               '...     list_operations()\n'
                                               '...     captured = capsys.readouterr()\n'
                                               '...     output = captured.out.splitlines()\n'
                                               "...     assert output[0] == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]'\n"
                                               "...     assert output[1] == '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11]'\n"
                                               "...     assert output[2] == '[0, 1, 2, 3, 5, 6, 7, 8, 9, 11]'\n"
                                               "...     assert output[3] == '10'\n",
                                       'hidden': True,
                                       'locked': False},
                                   {'code': '>>> test_list_operations()\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
