OK_FORMAT = True

test = {   'name': 'e2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_datatype_casting(capsys):\n'
                                               '...     datatype_casting()\n'
                                               '...     captured = capsys.readouterr()\n'
                                               '...     output = captured.out.splitlines()\n'
                                               '...     assert output[0] == \'a = {1.00}, b = \\t{8}, c = "{0}"\'\n',
                                       'hidden': True,
                                       'locked': False},
                                   {'code': '>>> test_datatype_casting(capsys)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
