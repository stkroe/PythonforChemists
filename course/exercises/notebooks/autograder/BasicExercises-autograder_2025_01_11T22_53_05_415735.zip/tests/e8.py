OK_FORMAT = True

test = {   'name': 'e8',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_loops_conditions(capsys):\n'
                                               '...     loops_conditions()\n'
                                               '...     captured = capsys.readouterr()\n'
                                               '...     output = captured.out.splitlines()\n'
                                               "...     assert output == ['2', '4', '6', '8', '10']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> test_loops_conditions(capsys)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
