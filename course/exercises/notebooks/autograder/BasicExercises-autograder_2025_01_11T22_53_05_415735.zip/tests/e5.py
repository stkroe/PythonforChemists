OK_FORMAT = True

test = {   'name': 'e5',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_count_characters():\n'
                                               '...     assert count_characters(\'hello\') == "The string \'hello\' has 5 characters."\n'
                                               '...     assert count_characters(\'\') == "The string \'\' has 0 characters."\n',
                                       'hidden': True,
                                       'locked': False},
                                   {'code': '>>> test_count_characters()\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
