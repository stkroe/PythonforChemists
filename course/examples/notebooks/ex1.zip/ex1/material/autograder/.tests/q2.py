OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_datatype_casting(out):\n'
                                               '...     output = out.splitlines()\n'
                                               '...     assert output[0] == \'a = 1.00, b = \\t8, c = "False"\'\n'
                                               '>>> test_datatype_casting(out)\n',
                                       'hidden': True,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
