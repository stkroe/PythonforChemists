OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_print_working_directory(out):\n'
                                               '...     output = out.strip()\n'
                                               '...     assert output == os.getcwd()\n'
                                               '>>> test_print_working_directory(out)\n',
                                       'hidden': True,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
