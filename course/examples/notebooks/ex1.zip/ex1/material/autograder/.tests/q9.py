OK_FORMAT = True

test = {   'name': 'q9',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_list_comprehension(list_comprehension):\n'
                                               '...     assert list_comprehension() == [0, 2, 4, 6, 8]\n'
                                               '>>> test_list_comprehension(list_comprehension)\n',
                                       'hidden': True,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
