OK_FORMAT = True

test = {   'name': 'q8',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_loops_conditions(out):\n'
                                               '...     output = out.splitlines()\n'
                                               "...     assert output == ['2', '4', '6', '8']\n"
                                               '>>> test_loops_conditions(out)\n',
                                       'hidden': True,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
