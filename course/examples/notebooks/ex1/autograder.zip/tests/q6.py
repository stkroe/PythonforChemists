OK_FORMAT = True

test = {   'name': 'q6',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_my_list(my_list):\n...     assert my_list() == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]\n>>> test_my_list(my_list)\n',
                                       'hidden': True,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
