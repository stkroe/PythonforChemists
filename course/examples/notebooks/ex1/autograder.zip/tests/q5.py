OK_FORMAT = True

test = {   'name': 'q5',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_count_characters(count_characters):\n'
                                               '...     assert count_characters(\'hello\') == "The string \'hello\' has 5 characters."\n'
                                               '...     assert count_characters(\'\') == "The string \'\' has 0 characters."\n'
                                               '>>> test_count_characters(count_characters)\n',
                                       'hidden': True,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
